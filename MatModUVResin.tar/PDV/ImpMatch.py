import os
import pandas as pd
import Hug as H
import FindPlat as FP
import numpy as np
import matplotlib as mpl
mpl.use('agg')

mpl.rcParams['figure.figsize']=[8,6]
mpl.rcParams['figure.dpi']=900
mpl.rcParams['font.size']=18
mpl.rcParams['font.family']='FreeSerif'
mpl.rcParams['legend.fontsize']=14
mpl.rcParams['lines.markersize']=8
mpl.rcParams['mathtext.fontset']='cm'

import matplotlib.pyplot as plt

#plt.rc('font',**{'family':'Serif','size':15})

#M=H.Mat(dens,s   ,c0  ) all SI units
Cu=H.Mat(8960,1.49,3940)
Al=H.Mat(2700,1.34,5350)
St=H.Mat(7900,1.49,4570)
mat=['Cu','St','Al']
#color=[[0.72,0.45,0.2],[0.72,0.25,0.05],[0.53,0.54,0.55]]
color=[[0.72,0.45,0.2],[0.25,0.00,0.10],[0.53,0.54,0.55]]
MAT=[Cu,St,Al]
d=os.listdir('./')
D=[]
for i in range(len(d)):
	if d[i][0]=='V':
		D.append(d[i])
#os.system('echo '+str(D))
UV_P=[]
UV_Up=[]
UV_Us=[]
UV_r=1214.3 #UV resin density according to Jack's excel sheet
f=plt.figure(dpi=200)
ax=f.gca()
f2=plt.figure(dpi=200)
ax2=f2.gca()
marker=["o","D","s"]
for i in range(len(D)):
	V=D[i][1:]
	#os.system('echo '+str(V))
	dir='V'+str(V)+'/'
	pdv0=pd.read_csv(dir+'Fl'+str(V)+'.csv')
	PDV0=np.array(pdv0).T
	Fl_V=int(V)#PDV0[1,1]
	#os.system('echo Fl_V = '+str(Fl_V))
	for j in range(3):
		F=mat[j]+str(V)+'.csv'
		pdv=pd.read_csv(dir+F)
		PDV=(np.array(pdv)).T
		#os.system('echo '+F)
		Plat=FP.find(PDV[1],0.03,0.06,6)
		#os.system('echo '+str(Plat))
		nn=4
		if (len(Plat)-1)>nn:
			N=nn
		else:
			N=len(Plat)-1
		for n in range(N): 
			VH=Plat[n]	#first huginoit plateau velocity
			VI=VH/2		#impedence match velocity
			PI=MAT[j].P((Plat[n+1]-Plat[n])/2)
			Up=Fl_V-(Plat[n]+Plat[n+1])/2
			Us=PI/(UV_r*Up)
			if (Us<3000) & (Us>100) & (Up>0):
				UV_P.append(PI)
				UV_Up.append(Up)
				UV_Us.append(PI/(UV_r*Up))
				if n==0: ms=10
				else: ms=5
				#if n==0:marker='o'
				#else:marker='.'
				ax.plot(Up,Us,marker[j],color=color[j],ms=ms)
#		plt.figure()
		for k in range(len(PDV[1])):
			if PDV[1][k]>10:
				tsh=PDV[0][k]*-1
				break
		tsh=tsh+1.5*i%2
		ax2.plot(PDV[0]+tsh,PDV[1],'-',color=color[j])
#		plt.hlines(Plat,0,max(PDV[0]),linestyles='dashed')
#ax2.set_title("UV Resin: Reverb Data")
ax2.grid()
ax2.set_xlim([-0.5,4.5])
ax2.set_ylim([0,500])
ax2.set_ylabel('Free-Surface Velocity ($u_p$) [$m/s$]')
ax2.set_xlabel('Time [$\mu s$]')
ax2.text(1.55,25,'$u_0=365\ m/s$',fontsize=14)
ax2.text(0.05,25,'$u_0=503\ m/s$',fontsize=14)
ax2.legend(['Copper','Steel','Aluminum'],edgecolor='k',fancybox=False)
f2.savefig("./PDV.png",bbox_inches='tight')
#		plt.close()
		
#os.system('echo '+str(UV_Up)+','+str(UV_Us))

#import matplotlib 
#matplotlib.use('agg')
#import matplotlib.pyplot as plt

#plt.figure(dpi=200)
ax.grid()
#plt.scatter(UV_Up,UV_Us)
#x.set_title('Us-up Hugoniot')
ax.set_xlabel('Particle Velocity, ($u_p$) [m/s]')
ax.set_ylabel('Shock Velocity, ($U_s$) [m/s]')
#plt.savefig('UpUs.png')


from sklearn.linear_model import LinearRegression as LR
Up=np.array([UV_Up])
Us=np.array([UV_Us])
reg=LR().fit(Up.T,Us.T)
#print(reg.get_params())
c=float(reg.predict(np.array([[0]])))
s=float(reg.predict(np.array([[1]]))-c)
ax2.text(150,160,'Us = '+str(c)+' + '+str(s)+'up',fontsize=18)
r2=reg.score(Up.T,Us.T)
print('c = '+str(c)+'\ns = '+str(s)+'\nr2 = '+str(r2))

UV=H.Mat(UV_r,s,c)
V=np.linspace(min(min(Up)),max(max(Up)))
#print(V)
ax.plot(V,UV.Us(V),'k--')
f.savefig('UpUs.pdf',bbox_inches='tight')

#print(UV.Us(V))
