'''
This program finds plateaus from a stair-steppy data set

It just looks for a certain number (n) of points that chanve less than a threshold (t1=M*p1)

However, to remove duplicates, the change across the previous n points must be less than t2

imputs (reccomended values):
	y,  data array
	p1, lower proportion threshold (0.03)
	p2, upper    ''         ''     (0.06)
	n,  number of points           (6   )

'''
import numpy as np
def find(y,p1,p2,n):
	P=[0]
	M=np.max(y)-np.min(y)
	t1=M*p1
	t2=M*p2
	I=0
	for i in range(len(y)-2*n):
		delta1=abs(y[i+2*n]-y[i])
		if delta1<t1:
			delta2=abs(y[i+n]-P[I])
			if delta2>t2:
				P.append(y[i+n])
				I=I+1
	return P
