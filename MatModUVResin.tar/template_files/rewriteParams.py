'''
This rewrites parameters from the params.in file to params.csv
rewriting makes it easier for pandas to read later

this is adventageous as this is only run once, but the params.csv needs to be read six times
'''
import os
import pandas as pd
import numpy as np

Fin='./params.in'
Fout='./params.csv'

with open(Fin) as F:
	lines=F.readlines()
words=[]
for line in lines:
	words.append(line.split())

n=int(words[0][0])

Dout=[]
for i in range(n):
	Dout.append(str(words[i+1][1])+','+str(round(float(words[i+1][0]),4))+'\n')
with open(Fout,'w') as P:
	P.write('Var,Val\n')
	for line in Dout:
		P.write(line)

