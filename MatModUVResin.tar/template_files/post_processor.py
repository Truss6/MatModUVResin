import os
import numpy as np
import pandas as pd
import time

N=6 # number of objective functions
f=[0 for _ in range(2*N)] #Init 12 objective functions as zeros
for I in range(N):
	os.system('python data_an.py '+str(I)+' &') # run data analyzer in BG
	time.sleep(0.2) # small pause must be included here
for I in range(N):
	unready=True # wait until each rundir has a results.out file
	while unready: # this section could be improved upon
		D=os.listdir('./rundir.'+str(I))
		for d in D:
			if d=='results.out':
				unready=False
				break
		time.sleep(0.1)
	with open('./rundir.'+str(I)+'/results.out','r') as R_in:
		r_in=pd.read_csv(R_in) # read results from rundir
		data=np.array(r_in).T
		for i in range(2):
			f[2*I+i]=data[0,i] # append to f
os.system('python plot.py') # plot data
with open('./results.out','w') as R_out:
	for j in range(2*N):
		R_out.write(str(f[j])+' f'+str(j)+'\n') # wirte results.out in workdir
# NOTE: the results.out file needs to be formatted exactly like this
