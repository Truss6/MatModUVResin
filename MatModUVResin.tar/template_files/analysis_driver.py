import sys
import os
import pandas as pd

data=pd.read_csv('data_table.csv')
for j in range(6):
	os.system('cd rundir.'+str(j)+";{run simulation} > cthOut &"); 
# because of export restrictions, I may not include instructions for running CTH
# to make this operable, you must replace {...} with command to run simualtions
# make sure you run the modified setup, not the original
