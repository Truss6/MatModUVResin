'''
Hugoniot material class
'''
class Mat:
	r=[]
	s=[]
	c=[]
	Us=[]
	P=[]
	def __init__(self,r,s,c):
		self.r=r
		self.c=c
		self.s=s
		self.Us=lambda Up: c+Up*s
		self.P=lambda Up: r*Up*self.Us(Up)
