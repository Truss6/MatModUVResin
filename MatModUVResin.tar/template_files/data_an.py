'''
This script is responsible for calculating objective functions

I might make big changes to this script if wanted to do this again, but it works
'''
import os
import sys
import numpy as np
import pandas as pd
import Spline as Spl # this is a package I wrote and is included
import time

# plotting presets #
import matplotlib

matplotlib.rc('xtick', labelsize=12)
matplotlib.rc('ytick', labelsize=12)

matplotlib.use('agg')
from matplotlib import pyplot as plt

plt.rc('font',**{'family':'Serif'})

N=int(sys.argv[1])
rundir='rundir.'+str(N)
#os.system('cd rundir.'+str(N))

font = {'family': 'Serif','size':14}
titlefont= {'family':'Serif','size':20}

hsdat=rundir+'/HS'
unready=True;nohs=True
while unready: # wait for CTH to finish
	while nohs: # this section could be improved upon
		D=os.listdir(rundir)
		for d in D:
			if d=='hscth':
				nohs=False
		time.sleep(2)
	os.system('python rewriteHS.py '+str(N)) # write hscth to HS
	hd=pd.read_csv(hsdat) # read HS
	HD=(np.array(hd)).T
	if float(max(HD[0]))>2.9e-6: # has time reached threshold
		unready=False # continue
	else:
		time.sleep(10) # wait
# in this particular optimization, I did not run the risk of simulations crashing
# if this is a possability, consider throwing a flag if the sim takes too long (or if the outut file says there is a crash)
# then return an extreem value without attempting to calculate the objective function
os.system('python rewriteHS.py '+str(N)) # final reformat datafile
pdvdat=rundir+'/PDV.dat'
tabdat='./data_table.csv'
outfile=rundir+'/results.out'

pdv=pd.read_csv(pdvdat) # read exp data
hs=pd.read_csv(hsdat) # read sim data
tab=pd.read_csv(tabdat) # read info from data_table.csv

PDV=(np.array(pdv)).T
HS=(np.array(hs)).T

for i in range(len(HS[3])):	#this section finds the refrence point
	if HS[3,i]>float(tab.vref[N]): # compare to threshold
		Tsh=HS[0,i] # set time shift
		break


#	~~~Plot Data~~~
plt.figure(dpi=300)
plt.plot((HS[0]-Tsh)*1e6,HS[3]*1e-2,label='Simulation')
plt.plot(PDV[0]-tab.tsh[N],PDV[1],label='Experiment')
plt.xlim([-0.5,2.5])

v_max=PDV[1,-1]

plt.vlines([tab.tl1[N],tab.th1[N],tab.tl2[N],tab.th2[N]]-tab.tsh[N],0,v_max,linestyle='--')#4*tab.vref[N])

plt.title(tab.target[N]+' '+str(tab.vel[N])+' m/s',fontdict=titlefont)
plt.xlabel("Time [us]",fontdict=font)
plt.ylabel("Free-Surface Velocity [m/s]",fontdict=font)
plt.legend(prop = font,loc='lower right')
plt.savefig(rundir+'/Plot.png')
#	~~~Building Splines~~~
SpHs=Spl.Spline((HS[0]-Tsh)*1e6,HS[3]*1e-2) # spline sim data
SpPDV=Spl.Spline(PDV[0]-tab.tsh[N],PDV[1]) # spline exp data

SpHs.LInterp() # linearly interpolate
SpPDV.LInterp() # initialy I used a cubic spline, but this was much too slow

delta=lambda t: (SpHs.f(t)-SpPDV.f(t))**2 # calc difference-squared for any time
# note that an error will be thrown if a time is requested outside of the limits

n=200 # for 200 points per plateau
t1=np.linspace(tab.tl1[N],tab.th1[N],n)-tab.tsh[N] # time array (plateau 1)
dt1=(t1[1]-t1[0])/1e-0 # time step

t2=np.linspace(tab.tl2[N],tab.th2[N],n)-tab.tsh[N] # '' (plateau 2)
dt2=(t2[1]-t2[0])/1e-0 # ''
#	~~~Integrating~~~
Int1=0;Int2=0;
for i in range(n-1):
	Int1+=(delta(t1[i+1])+delta(t1[i]))*dt1/2 # trapezoidal integration
	Int2+=(delta(t2[i+1])+delta(t2[i]))*dt2/2

Int1=(Int1/((tab.th1[N]-tab.tl1[N])))**0.5 # Root-mean
Int2=(Int2/((tab.th2[N]-tab.tl2[N])))**0.5


#	~~~Writing Results~~~
with open(outfile,'w') as O:
	O.write('C1,C2\n'+str(Int1)+', f0\n'+str(Int2)+', f1')
#	~~~Cleaning Up~~~
os.system("rm "+rundir+"/*cth*; rm "+rundir+"/Pressure*")
