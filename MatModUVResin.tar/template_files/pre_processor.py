'''
This script is brief, but orchestrates all the required setup
'''
import os

os.system('python rewriteParams.py') # rewrite params.in to params.csv
for i in range(6):
	os.system('python write_setup.py '+str(i)) # write setup in each dir
