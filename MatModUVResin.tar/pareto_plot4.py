from math import *
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("agg")
matplotlib.rc('xtick', labelsize= 8)
matplotlib.rc('ytick', labelsize= 8)
import matplotlib.pyplot as plt
import sys

NGEN=int(sys.argv[1])

plt.rc('font',**{'family':'Serif'})
font = {'family': 'Serif','size':14}
titlefont= {'family':'Serif','size':20}


##	Extract Data	##
words=[]
with open('data_table.dat') as D:
	lines=D.readlines()


##	parameters	##
inf=1e308
opt=inf
ppg=100	#population per generation
gens=100#(len(words)/ppg)+1


for i in range(NGEN*ppg):
	words.append(lines[i].split())

##	plotting	##
f,ax = plt.subplots(2,3,dpi=300)
def p_plot(i,marker='.'):
	g=1+(i/ppg)
	s=exp(0.125*(1-g))
	C=[(s)**2,4*(1-s)*s,(1-s)**2]
	alpha=0.125*exp(0.03125*(1-g))
	size=s*5+1
	if marker=='*':
		size=5
		alpha=1
	if marker=='x':
		alpha=2*alpha
        for e in range(6):
                if e>2:
                        I1=1
                else:
                        I1=0
                I2=e-3*I1
                n1=-2*e-2
                n2=-2*e-1

		ax[I1,I2].loglog(float(words[i][n1]),float(words[i][n2]),marker=marker,color=C,markersize=size,alpha=alpha)
	

print(words[0][:]) #print column names

# init vars
I=0
pareto_params=[]
no=12		#	Number of Objective Functions

##	find minimums		##
opts=[inf for _ in range(no)] 
opt=inf
for o in range(no):
	for i in range(1,len(words)):
		if (float(words[i][-o-1])<opts[1-o]):
			opts[1-o]=float(words[i][-o-1]) #could probably use min(...)
S=[0 for _ in range(len(words))]
for i in range(1,len(words)):
	for o in range(no): S[i]+=(float(words[i][-o-1])-opts[1-o])**2
	if S[i]<opt:
		opt=S[i]
		top_dog=words[i]
		Index=i
S=np.array(S)
with open('topPerformers','w') as tP:
	for word in words[0]:
		tP.write(word+',')
	tP.write('\n')
	for i in S.argsort()[1:100]:
		for j in range(len(words[0])):
			tP.write(words[i][j]+',')
		tP.write('\n')
for i in range(1,len(words)):
	marker='.'
	p_plot(i,marker=marker)
print("\nBest Performer: \n")
print(top_dog)
p_plot(Index,marker='*')
print("\n")
for I in [0,1,2]:
	for J in [0,1]:	
		ax[J,I].grid()
plt.savefig('pPlot'+str(NGEN).zfill(3)+'.png',bbox_inches='tight')

with open('ParetoParams.csv','w') as Out:
	for word in words[0]:
		Out.write(word+',')
	Out.write('\n')
	for i in range(len(pareto_params)):
		for j in range(len(pareto_params[0])):
			Out.write(pareto_params[i][j]+',')
		Out.write('\n')

