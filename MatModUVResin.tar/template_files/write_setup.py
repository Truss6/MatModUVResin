'''
This program reads params.csv and modifies setup files
'''
import numpy as np
import os
import pandas as pd
import sys

N=sys.argv[1] # which rundir
rundir='./rundir.'+N

paramsFile='./params.csv'
setupFile=rundir+'/setup'
outFile=rundir+'/cth_setup' # writes setup to cth_setup
varNames=[]
varValues=[]
params=np.array(pd.read_csv(paramsFile))
for i in range(len(params)):
	varNames.append('{'+params[i,0]+'}') # variable tags
	varValues.append(params[i,1]) # variable values
with open(setupFile,'r') as Sin:
	Slines=Sin.readlines() # read setup.in
for i in range(len(varNames)):
	for j in range(len(Slines)):
		Slines[j]=Slines[j].replace(varNames[i],str(varValues[i])) # replace variable tags with values
# note, reading setup into list of lines was unnecessary but works as well as reading all at once
with open(outFile,'w') as Sout:
	for line in Slines:
		Sout.write(line) # write modified setup.out
