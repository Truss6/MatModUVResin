import os
import sys
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import time

#	argv:
#	1: input name
#	2: output name

fname=sys.argv[1]
c=299792458

data=pd.read_csv(fname,delimiter=' ')
DATA=np.array(data)
t=DATA[:,0]*1e6
L=DATA[:,1]
L0=DATA[:,2]

n=len(t)
v=np.zeros(n)

Vel = lambda ((f,f0)): (f)/(2*193414e9)*c

r=np.average(Vel((L[0:10],L0[0:10])))
os.system('echo beat floor:' +str(r))
#time.pause(1)

for i in range(n):
	v[i]=Vel((L[i],L0[i]))-r

with open(sys.argv[2],'w') as O:
	for i in range(n):
		O.write(str(t[i])+','+str(v[i])+'\n')
#os.sys('echo DONE')
