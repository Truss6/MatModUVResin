import numpy as np
import matplotlib
matplotlib.use('agg')
from matplotlib import pyplot as plt
from numpy import linalg as LA

class Spline: 
    x=[]
    y=[]
    X=[]
    Y=[]
    f=[]
    def __init__(self,x,y):
        self.x=x
        self.y=y
        if (len(x)!=len(y)):
            print("Input dimension mismatch!")
            print("Length of x = "+str(len(x))+". Length of y = "+str(len(y)))
    def LInterp(obj):
        x=obj.x
        y=obj.y
        n=len(x)
        p=10
        obj.f=lambda X: LI(obj,X,x,y)
        def LI(obj,X,x,y):
                Y=0
                for i in range(len(x)-1):
                        if X>x[i]:
                                if X<x[i+1]:
                                        m=(X-x[i])/(x[i+1]-x[i]) #this has been fixed
                                        Y=m*(y[i+1]-y[i])+y[i]
                return Y
    def QInterp(obj):
        x=obj.x
        y=obj.y
        n=len(x)
        p=10
        M=np.zeros(((n-1)*3,(n-1)*3))
        b=np.zeros((n-1)*3)
        for i in range(n-1):
            M[2*i,i]=x[i]**2
            M[2*i,i+(n-1)]=x[i]**1
            M[2*i,i+2*(n-1)]=1
            b[2*i]=y[i]
            
            M[2*i+1,i]=x[i+1]**2
            M[2*i+1,i+(n-1)]=x[i+1]
            M[2*i+1,i+2*(n-1)]=1
            b[2*i+1]=y[i+1]
        #    print(M)
        #    print(b)
        for i in range(n-2):
            M[2*(n-1)+i,i]=2*x[i+1]
            M[2*(n-1)+i,i+1]=-2*x[i+1]
            M[2*(n-1)+i,i+(n-1)]=1
            M[2*(n-1)+i,i+(n-1)+1]=-1
        #    print(M)

        M[(n-1)*3 -1,0]=1     #   Zero Second Derivative as X0
        #print(M)
        k=LA.solve(M,b.T)
        K=k.reshape(3,n-1).T
        #print(K)
        X=np.zeros(p*(n-1))
        Y=np.zeros(len(X))
        for i in range(n-1):
            X[p*i:p*(i+1)]=np.linspace(x[i],x[i+1],p)
            for j in range(p):
                I=p*i+j
                Y[I]=K[i,0]*X[I]**2+K[i,1]*X[I]+K[i,2]
        obj.X=X
        obj.Y=Y
    def CInterp(obj):	
        #cubic spline interpolation
        #in my huble opinion, this is quite a nice little program
        #	#example implementation{	
        #	import Spline as Spl
        #	
        #	S=Spl.Spline(x,y)
        #	S.CInterp
        #	}
        x=obj.x	#inputs
        y=obj.y	#outputs
        n=len(x)
        p=10	#number of automatic spline points per 'piece' for n-1 pieces
        M=np.zeros(((n-1)*4,(n-1)*4))	#constraint matrix
        b=np.zeros((n-1)*4)	#constraint vector
        for i in range(n-1):
            #constraint A: the function must hit the data at either end of erery piece
            M[2*i,i]=x[i]**3
            M[2*i,i+(n-1)]=x[i]**2
            M[2*i,i+2*(n-1)]=x[i]**1
            M[2*i,i+3*(n-1)]=x[i]**0
            b[2*i]=y[i]	

            M[2*i+1,i]=x[i+1]**3
            M[2*i+1,i+(n-1)]=x[i+1]**2
            M[2*i+1,i+2*(n-1)]=x[i+1]**1
            M[2*i+1,i+3*(n-1)]=x[i+1]**0
            b[2*i+1]=y[i+1]
        #    print(M)
        #    print(b)
        for i in range(n-2):
            I=2*(n-1)+i
            #constraint B: the function must have equal first derivative on either side of every piece
            M[I,i]=3*x[i+1]**2
            M[I,i+1]=-3*x[i+1]**2
            M[I,i+(n-1)]=2*x[i+1]**1
            M[I,i+(n-1)+1]=-2*x[i+1]**1
            M[I,i+2*(n-1)]=1*x[i+1]**0
            M[I,i+2*(n-1)+1]=-1*x[i+1]**0

            
        for i in range(n-2):
            I=2*(n-1)+n-2+i
            #constraint C: "	"	"	second derivative	"	"	"
            M[I,i]=6*x[i+1]**1
            M[I,i+1]=-6*x[i+1]**1
            M[I,i+(n-1)]=2*x[i+1]**0
            M[I,i+(n-1)+1]=-2*x[i+1]**0
            
        
        #    print(M)
        #	constrain D (boundry constraint): the function must have zero second derivative at either endpoint
        M[-2+(n-1)*4,0]=1     #   Zero Second Derivative as X0
        M[-1+(n-1)*4,n-2]=1
        #print(M)
        k=LA.solve(M,b.T)	#Konstants=cMatrix\cVector
        K=k.reshape(4,n-1).T	#reshape so each column represents one piece
        #print(K)
        #X=np.zeros(p*(n-1))
        #Y=np.zeros(len(X))
        #for i in range(n-1):
        #    X[p*i:p*(i+1)]=np.linspace(x[i],x[i+1],p)
        #    for j in range(p):
        #        I=p*i+j
        #        Y[I]=K[i,0]*X[I]**3+K[i,1]*X[I]**2+K[i,2]*X[I]**1+K[i,3]*X[I]**0	#eval at auto-spline points
        obj.f=lambda X: QI(obj,X,K,x)	#lambda function to eval at any defined point
        #obj.X=X
        #obj.Y=Y
        
        def QI(obj,X,K,x):	#X is input(s) for desired output(s), K is Konstraints vector reshaped to a matrix, x is spline data inputs
                n=len(x)
                Y=None
                for i in range(n-1):
                    if (X>=x[i]) & (X<=x[i+1]):	#is X within this piece of the spline?
                        Y=K[i,0]*X**3+K[i,1]*X**2+K[i,2]*X**1+K[i,3]	#eval cubic polynomial
                return Y
        
class bispline:
    S=[]	#array of 1D spline objects along X(at certain Y positions)
    Y=[]	#spec'd y-positions
    f=[]	#output lambda function to find any defined point
    def __init__(self,S,Y):
        self.S=S
        self.Y=Y
        self.f=lambda u,v: self.bispl(u,v)
    def bispl(obj,u,v):
        z=[None for i in range(len(obj.Y))]
        for i in range(len(obj.Y)):
            z[i]=obj.S[i].f(u)	#create z-array of data from spline interpolation at x-position
        SS=Spline(obj.Y[:,i],z)	#make spline z along y-direction
        SS.CInterp()		#cubic spline interpolation
        return SS.f(v)		#output value at y-position
