'''
this plots sim data against experimental
'''
import os
import sys
import numpy as np
import pandas as pd
import Spline as Spl
import time
### plotting presets ###
import matplotlib

matplotlib.rc('xtick', labelsize=12)
matplotlib.rc('ytick', labelsize=12)

matplotlib.use('agg')
from matplotlib import pyplot as plt

plt.rc('font',**{'family':'Serif'})

font = {'family': 'Serif','size':14}
titlefont= {'family':'Serif','size':20}

hsdat='/HS'
pdvdat='/PDV.dat'
tabdat='./data_table.csv'

plt.figure(dpi=200)
t_shift=[2,0.5,0]
for I in [0,1]:
	for J in [0,1,2]:
		N=3*I+J
		rund='rundir.'+str(N)
		
		pdv=pd.read_csv(rund+pdvdat)
		hs=pd.read_csv(rund+hsdat)
		tab=pd.read_csv(tabdat)
		
		PDV=(np.array(pdv)).T
		HS=(np.array(hs)).T
		
		for i in range(len(HS[3])):	#this section finds the refrence point
			if HS[3,i]>float(tab.vref[N]):
				Tsh=HS[0,i]
				break
		#	~~~Plot Data~~~
		c=J/2.0
		C=[c**2,3*c*(1-c),(1-c)**2]
		plt.plot(t_shift[J]+(HS[0]-Tsh)*1e6,HS[3]*1e-2,'--',color=C)
		plt.plot(t_shift[J]+PDV[0]-tab.tsh[N],PDV[1],'-',color=C)
plt.xlim([-0.5,5.00])

plt.title('Model Comparison')
plt.xlabel("Time [us]",fontdict=font)
plt.ylabel("Free-Surface Velocity [m/s]",fontdict=font)
plt.savefig('./Plot.png')
