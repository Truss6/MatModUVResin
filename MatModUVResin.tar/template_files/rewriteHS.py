'''
This script reformats the cth output data file, hscth

This can probably be accomplished by: pd.read_csv('...',skiplines=[0,2],comment='%')
	But at the time I hadn't figured that out
'''
import sys

N=sys.argv[1] # which rundir

inF='./rundir.'+N+'/hscth'
outF='./rundir.'+N+'/HS'

with open(inF,'r') as I:
	data=I.readlines()
with open(outF,'w') as O:
	for i in range(len(data)):
		if i!=0:
			if i!=2:
				O.write(data[i])
